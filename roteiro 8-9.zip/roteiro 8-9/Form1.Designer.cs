﻿namespace roteiro_8_9
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel1 = new Panel();
            button4 = new Button();
            button5 = new Button();
            label1 = new Label();
            button2 = new Button();
            button1 = new Button();
            panel2 = new Panel();
            button3 = new Button();
            btnForm3 = new Button();
            btnForm4 = new Button();
            btnForm5 = new Button();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(959, 79);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            panel1.MouseMove += panel1_MouseDown;
            // 
            // button4 (restaurar)
            // 
            button4.Location = new Point(880, 0);
            button4.Name = "button4";
            button4.Size = new Size(25, 23);
            button4.TabIndex = 3;
            button4.Text = "_";
            button4.UseVisualStyleBackColor = true;
            button4.Click += btnRestaurar_Click;
            button4.Visible = false;
            // 
            // button5 (maximizar)
            // 
            button5.Location = new Point(911, 0);
            button5.Name = "button5";
            button5.Size = new Size(27, 23);
            button5.TabIndex = 4;
            button5.Text = "M";
            button5.UseVisualStyleBackColor = true;
            button5.Click += btnMaximizar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(3, 0);
            label1.Name = "label1";
            label1.Size = new Size(81, 15);
            label1.TabIndex = 1;
            label1.Text = "MEU SISTEMA";
            // 
            // button2
            // 
            button2.Location = new Point(944, 191);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 1;
            button2.Text = "button2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1 (fechar)
            // 
            button1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            button1.BackColor = Color.Transparent;
            button1.FlatAppearance.BorderColor = Color.White;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseDownBackColor = Color.FromArgb(64, 64, 64);
            button1.FlatAppearance.MouseOverBackColor = Color.Red;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = SystemColors.ActiveBorder;
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.Location = new Point(1103, 0);
            button1.Name = "button1";
            button1.Size = new Size(27, 15);
            button1.TabIndex = 0;
            button1.Text = "\"\"";
            button1.UseVisualStyleBackColor = false;
            button1.Click += btnFechar_Click;
            // 
            // panel2 (menu lateral)
            // 
            panel2.BackColor = SystemColors.ControlDark;
            panel2.Controls.Add(btnForm5);
            panel2.Controls.Add(btnForm4);
            panel2.Controls.Add(btnForm3);
            panel2.Controls.Add(button3);
            panel2.ForeColor = Color.White;
            panel2.Location = new Point(0, 85);
            panel2.Name = "panel2";
            panel2.Size = new Size(161, 445);
            panel2.TabIndex = 2;
            panel2.Paint += panel2_Paint;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ActiveCaptionText;
            button3.FlatAppearance.BorderColor = Color.White;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.MouseDownBackColor = Color.White;
            button3.FlatAppearance.MouseOverBackColor = Color.Goldenrod;
            button3.FlatStyle = FlatStyle.Flat;
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(24, 26);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 3;
            button3.Text = "Clientes";
            button3.UseVisualStyleBackColor = false;
            // 
            // btnForm3
            // 
            btnForm3.Location = new Point(24, 70);
            btnForm3.Name = "btnForm3";
            btnForm3.Size = new Size(100, 30);
            btnForm3.TabIndex = 4;
            btnForm3.Text = "Form 3";
            btnForm3.UseVisualStyleBackColor = true;
            btnForm3.Click += buttonForm3_Click;
            // 
            // btnForm4
            // 
            btnForm4.Location = new Point(24, 110);
            btnForm4.Name = "btnForm4";
            btnForm4.Size = new Size(100, 30);
            btnForm4.TabIndex = 5;
            btnForm4.Text = "Form 4";
            btnForm4.UseVisualStyleBackColor = true;
            btnForm4.Click += buttonForm4_Click;
            // 
            // btnForm5
            // 
            btnForm5.Location = new Point(24, 150);
            btnForm5.Name = "btnForm5";
            btnForm5.Size = new Size(100, 30);
            btnForm5.TabIndex = 6;
            btnForm5.Text = "Form 5";
            btnForm5.UseVisualStyleBackColor = true;
            btnForm5.Click += buttonForm5_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(959, 545);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button button1;
        private Button button2;
        private Label label1;
        private Panel panel2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button btnForm3;
        private Button btnForm4;
        private Button btnForm5;
    }
}
